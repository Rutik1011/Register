package example.mvc.contro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RegesPojo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String fnm;
	String mnm;
	String lnm;
	String bdate;
	String cont;
	String gen;
	String email;
	String moNo;
	public RegesPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RegesPojo(String fnm, String mnm, String lnm, String bdate, String cont, String gen, String email, String moNo) {
		super();
		this.fnm = fnm;
		this.mnm = mnm;
		this.lnm = lnm;
		this.bdate = bdate;
		this.cont = cont;
		this.gen = gen;
		this.email = email;
		this.moNo = moNo;
	}
	public String getFnm() {
		return fnm;
	}
	public void setFnm(String fnm) {
		this.fnm = fnm;
	}
	public String getMnm() {
		return mnm;
	}
	public void setMnm(String mnm) {
		this.mnm = mnm;
	}
	public String getLnm() {
		return lnm;
	}
	public void setLnm(String lnm) {
		this.lnm = lnm;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getCont() {
		return cont;
	}
	public void setCont(String cont) {
		this.cont = cont;
	}
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMoNo() {
		return moNo;
	}
	public void setMoNo(String moNo) {
		this.moNo = moNo;
	}
	@Override
	public String toString() {
		return "RegesPojo [fnm=" + fnm + ", mnm=" + mnm + ", lnm=" + lnm + ", bdate=" + bdate + ", cont=" + cont + ", gen="
				+ gen + ", email=" + email + ", moNo=" + moNo + "]";
	}

}
